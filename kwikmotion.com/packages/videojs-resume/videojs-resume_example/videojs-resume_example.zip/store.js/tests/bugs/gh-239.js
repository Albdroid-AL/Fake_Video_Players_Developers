/* eslint semi: "off", no-unused-vars: "off" */

var store = require('../..');
const set = (key, value) => store.set(key, value); 
const get = key => store.get(key);