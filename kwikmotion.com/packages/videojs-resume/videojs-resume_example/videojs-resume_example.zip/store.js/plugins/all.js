module.exports = [
	require('./compression'),
	require('./defaults'),
	require('./dump'),
	require('./events'),
	require('./observe'),
	require('./expire'),
	require('./json2'),
	require('./operations'),
	require('./update'),
	require('./v1-backcompat'),
]
